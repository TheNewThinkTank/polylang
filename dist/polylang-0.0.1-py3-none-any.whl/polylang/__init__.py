from .src.gui import (
    FlashcardGUI,
)