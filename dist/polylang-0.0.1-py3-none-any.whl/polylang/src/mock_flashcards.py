mock_flashcards = {
    "apple": "a round fruit with red or green skin and a white inside",
    "book": "a written or printed work consisting of pages glued or sewn together along one side and bound in covers",
    "car": "a road vehicle powered by an internal combustion engine or an electric motor",
    "dog": "a domesticated carnivorous mammal that typically has a long snout, an acute sense of smell, and a barking, howling, or whining voice",
    "elephant": "a very large plant-eating mammal with a prehensile trunk, long curved ivory tusks, and large ears",
    "friend": "a person whom one knows and with whom one has a bond of mutual affection",
    "house": "a building for human habitation, especially one that is lived in by a family or small group of people",
    "internet": "a global computer network providing a variety of information and communication facilities",
    "jacket": "a short coat, typically with long sleeves and made from a thick material, worn as part of one's outfit or as protective clothing",
    "kangaroo": "a large plant-eating marsupial with a long powerful tail and strongly developed hindlimbs that enable it to travel by leaping",
}
